from enum import Enum


class ENV(Enum):
    TEST=0
    DEV=1
    PROD=2
    TEST1=3
    CLOUD1=4
    CLOUD2=5
    PROD1=6
    PROD2=7

    PROD2_TMP = 8 # 零时配置